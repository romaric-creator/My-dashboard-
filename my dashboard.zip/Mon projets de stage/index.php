<?php
    $host="localhost";
    $user="root";
    $password="";
    $base="my dashboard";

    $conn = mysqli_connect($host,$user,$password);
    $sqls = mysqli_select_db($conn,$base);
    if($sqls){
        header("Location: php/home.php");
    }else{
        header("Location: php/install.php#t1");
    }
?>