<div class="footer">
    <ul>
        <li><a href="tel:678261699">contact</a></li>
        <li><a href="mailto:christiantendainfo2006@gmail.com">envoyer un mail</a></li>
        <li><a href="#">site officiel</a></li>
    </ul>
</div>